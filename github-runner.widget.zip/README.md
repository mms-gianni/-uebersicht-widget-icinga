# uebersicht widget for github runners
Widget for Übersicht http://tracesof.net/uebersicht/ to display your current github action runners


